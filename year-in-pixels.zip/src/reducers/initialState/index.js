export const color = {
  blue: "sad",
  red: "angry",
  green: "happy"
}

export const year = {
  january: [],
  february: [],
  march: [],
  april: [],
  may: [],
  june: [],
  july: [],
  august: [],
  september: [],
  october: [],
  november: [],
  december: []
}
